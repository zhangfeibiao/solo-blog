title: MySQL-库表索引的设计
date: '2020-07-05 19:49:37'
updated: '2020-07-05 23:32:40'
tags: [mysql]
permalink: /articles/2020/07/05/1593949777404.html
---
## 规范

### 库

* 命名规范：驼峰
* 库名要能体现业务范围

### 表

* 命名规范：驼峰
* 表名称要能反映出功能
* 表必须要有注释

### 列

* 命名规范：小写字母
* 列名要能表达具体含义，比如shopid,userid
* 列的数据类型尽量选择整型，并且范围够用即可
* 列必须要有注释

### 索引

* 命名规范：普通索引 IX_<column1_column2,,,>，唯一索引 UK_<column1_column2,,,>

## 索引介绍

### 什么是索引

索引是存储引擎用于快速找到记录的一种数据结构

### 常见索引类型

BTREE，HASH，全文索引等

![image.png](https://b3logfile.com/file/2020/07/image-85c18dcb.png)

![image.png](https://b3logfile.com/file/2020/07/image-dc9c45c2.png)

### 数据组织方式

聚簇，非聚簇

聚簇索引：表记录的物理存储顺序与索引顺序一致，且索引的叶子节点就是数据节点

非聚簇索引：表记录的物理存储顺序与索引顺序无关，叶节点包含主键值或指向数据块的

指针（因存储引擎而异，InnoDB存放主键和索引键值，MyISAM存放数据库指针）

![image.png](https://b3logfile.com/file/2020/07/image-a5d86bab.png)

## 索引如何设计

### 哪些列建议创建索引

WHERE,    JOIN ,     GROUP BY,      ORDER BY   等语句使用的列

### 利用最左前缀

（A, B, C)：A,  A&B,  A&C, A&B&C, B, C, B&C

### 如何选择索引列的顺序

经常被使用到的列优先，利用最左前缀，尽量复用已有索引

区分度大的列优先，区分度 = distinct(col) / count(col) ， distinct(col) 即cardinality，至少大于0.1，尽快排除掉更多的记录

宽度小的列优先，列宽度 = 列的数据类型，宽度越小，单节点的key值越多，索引树的高度越低，查询复杂度越低
